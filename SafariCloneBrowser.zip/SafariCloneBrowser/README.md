# Safari Clone Browser (`com.shivaji.browser`)

Minimal iOS Safari-inspired Android browser written in Kotlin (SDK 34, Min SDK 24).

## Features
- Edge-to-edge transparent system bars with `WindowInsets` IME-aware floating pill bar
- Liquid Glass translucent dark UI with `SpringAnimation` launch and scroll auto-hide/show
- Custom `start.html` with Favorites grid and live Privacy Report counter
- Silent background ad/popunder/tracker blocker in `WebViewClient`
- 4-thread parallel download engine (`16 KB` buffers, redirect resolution, Scoped Storage `MediaStore.Downloads` support) with floating Liquid Glass download sheet
- GitHub Actions CI workflow (`.github/workflows/build.yml`)
