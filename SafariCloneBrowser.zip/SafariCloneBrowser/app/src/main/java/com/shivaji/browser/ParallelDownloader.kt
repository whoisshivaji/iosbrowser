package com.shivaji.browser

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.webkit.CookieManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

class ParallelDownloader(private val context: Context) {

    interface Listener {
        fun onStart(fileName: String, totalBytes: Long)
        fun onProgress(
            downloadedBytes: Long,
            totalBytes: Long,
            speedBytesPerSec: Long,
            etaSeconds: Long
        )
        fun onComplete(fileName: String)
        fun onError(message: String)
        fun onCancelled()
    }

    private var activeJob: Job? = null
    private val cancelled = AtomicBoolean(false)

    fun startDownload(
        rawUrl: String,
        fileName: String,
        mimeType: String,
        userAgent: String,
        scope: CoroutineScope,
        listener: Listener
    ) {
        cancel()
        cancelled.set(false)

        activeJob = scope.launch(Dispatchers.IO) {
            val tempDir = File(context.cacheDir, "dl_parts_${System.currentTimeMillis()}")
            tempDir.mkdirs()

            try {
                val resolvedUrl = resolveRedirects(rawUrl, userAgent)
                val probe = probeRemoteFile(resolvedUrl, userAgent)
                val totalBytes = probe.contentLength
                val supportsRanges = probe.acceptRanges && totalBytes > MIN_MULTITHREAD_SIZE

                withContext(Dispatchers.Main) {
                    listener.onStart(fileName, totalBytes)
                }

                val downloadedCounter = AtomicLong(0L)
                val startTimeMs = System.currentTimeMillis()

                // Progress reporter coroutine
                val reporterJob = launch(Dispatchers.IO) {
                    var lastBytes = 0L
                    var lastTime = startTimeMs
                    while (isActive && !cancelled.get()) {
                        kotlinx.coroutines.delay(350L)
                        val now = System.currentTimeMillis()
                        val currentBytes = downloadedCounter.get()
                        val deltaTimeMs = (now - lastTime).coerceAtLeast(1L)
                        val deltaBytes = (currentBytes - lastBytes).coerceAtLeast(0L)
                        val instantSpeed = (deltaBytes * 1000L) / deltaTimeMs
                        val elapsedSec = ((now - startTimeMs) / 1000.0).coerceAtLeast(0.5)
                        val avgSpeed = (currentBytes / elapsedSec).toLong()
                        val effectiveSpeed = if (instantSpeed > 0) instantSpeed else avgSpeed

                        val etaSeconds = if (totalBytes > 0 && effectiveSpeed > 0) {
                            ((totalBytes - currentBytes).coerceAtLeast(0L)) / effectiveSpeed
                        } else {
                            -1L
                        }

                        lastBytes = currentBytes
                        lastTime = now

                        withContext(Dispatchers.Main) {
                            if (!cancelled.get()) {
                                listener.onProgress(currentBytes, totalBytes, effectiveSpeed, etaSeconds)
                            }
                        }
                    }
                }

                val mergedFile = File(tempDir, "merged_output.tmp")

                if (supportsRanges) {
                    val partSize = totalBytes / THREAD_COUNT
                    val partJobs = (0 until THREAD_COUNT).map { index ->
                        val start = index * partSize
                        val end = if (index == THREAD_COUNT - 1) totalBytes - 1 else (start + partSize - 1)
                        val partFile = File(tempDir, "part_$index.tmp")
                        async(Dispatchers.IO) {
                            downloadChunk(
                                urlString = resolvedUrl,
                                userAgent = userAgent,
                                startByte = start,
                                endByte = end,
                                outputFile = partFile,
                                counter = downloadedCounter
                            )
                            partFile
                        }
                    }
                    val partFiles = partJobs.awaitAll()
                    if (cancelled.get()) {
                        reporterJob.cancel()
                        withContext(Dispatchers.Main) { listener.onCancelled() }
                        return@launch
                    }
                    mergeParts(partFiles, mergedFile)
                } else {
                    downloadSingleStream(
                        urlString = resolvedUrl,
                        userAgent = userAgent,
                        outputFile = mergedFile,
                        counter = downloadedCounter
                    )
                }

                reporterJob.cancel()

                if (cancelled.get()) {
                    withContext(Dispatchers.Main) { listener.onCancelled() }
                    return@launch
                }

                saveToScopedDownloads(mergedFile, fileName, mimeType)

                withContext(Dispatchers.Main) {
                    listener.onProgress(
                        downloadedCounter.get(),
                        if (totalBytes > 0) totalBytes else downloadedCounter.get(),
                        0L,
                        0L
                    )
                    listener.onComplete(fileName)
                }
            } catch (e: Exception) {
                if (!cancelled.get()) {
                    withContext(Dispatchers.Main) {
                        listener.onError(e.message ?: "Download failed")
                    }
                }
            } finally {
                tempDir.deleteRecursively()
            }
        }
    }

    fun cancel() {
        cancelled.set(true)
        activeJob?.cancel()
        activeJob = null
    }

    private data class ProbeResult(val contentLength: Long, val acceptRanges: Boolean)

    private fun resolveRedirects(initialUrl: String, userAgent: String): String {
        var current = initialUrl
        for (hop in 0 until MAX_REDIRECTS) {
            val conn = openConnection(current, userAgent, "HEAD")
            conn.instanceFollowRedirects = false
            try {
                val code = conn.responseCode
                if (code in 300..399) {
                    val location = conn.getHeaderField("Location") ?: break
                    current = URL(URL(current), location).toString()
                } else {
                    break
                }
            } finally {
                conn.disconnect()
            }
        }
        return current
    }

    private fun probeRemoteFile(urlString: String, userAgent: String): ProbeResult {
        val conn = openConnection(urlString, userAgent, "HEAD")
        return try {
            val code = conn.responseCode
            if (code in 200..299) {
                val len = conn.getHeaderField("Content-Length")?.toLongOrNull() ?: -1L
                val acceptRanges = conn.getHeaderField("Accept-Ranges")
                    ?.equals("bytes", ignoreCase = true) == true
                ProbeResult(len, acceptRanges)
            } else {
                ProbeResult(-1L, false)
            }
        } catch (_: Exception) {
            ProbeResult(-1L, false)
        } finally {
            conn.disconnect()
        }
    }

    private fun downloadChunk(
        urlString: String,
        userAgent: String,
        startByte: Long,
        endByte: Long,
        outputFile: File,
        counter: AtomicLong
    ) {
        val conn = openConnection(urlString, userAgent, "GET")
        conn.setRequestProperty("Range", "bytes=$startByte-$endByte")
        try {
            val code = conn.responseCode
            if (code != HttpURLConnection.HTTP_PARTIAL && code != HttpURLConnection.HTTP_OK) {
                throw IllegalStateException("HTTP $code for range $startByte-$endByte")
            }
            conn.inputStream.use { input ->
                FileOutputStream(outputFile).use { output ->
                    copyWith16KbBuffer(input, output, counter)
                }
            }
        } finally {
            conn.disconnect()
        }
    }

    private fun downloadSingleStream(
        urlString: String,
        userAgent: String,
        outputFile: File,
        counter: AtomicLong
    ) {
        val conn = openConnection(urlString, userAgent, "GET")
        try {
            val code = conn.responseCode
            if (code !in 200..299) {
                throw IllegalStateException("HTTP $code")
            }
            conn.inputStream.use { input ->
                FileOutputStream(outputFile).use { output ->
                    copyWith16KbBuffer(input, output, counter)
                }
            }
        } finally {
            conn.disconnect()
        }
    }

    private fun copyWith16KbBuffer(
        input: InputStream,
        output: OutputStream,
        counter: AtomicLong?
    ) {
        val buffer = ByteArray(BUFFER_SIZE_16KB)
        var bytesRead: Int
        while (!cancelled.get()) {
            bytesRead = input.read(buffer)
            if (bytesRead == -1) break
            output.write(buffer, 0, bytesRead)
            counter?.addAndGet(bytesRead.toLong())
        }
        output.flush()
    }

    private fun mergeParts(partFiles: List<File>, destination: File) {
        FileOutputStream(destination).use { out ->
            val buffer = ByteArray(BUFFER_SIZE_16KB)
            for (part in partFiles) {
                FileInputStream(part).use { input ->
                    var read: Int
                    while (!cancelled.get()) {
                        read = input.read(buffer)
                        if (read == -1) break
                        out.write(buffer, 0, read)
                    }
                }
            }
            out.flush()
        }
    }

    private fun saveToScopedDownloads(sourceFile: File, fileName: String, mimeType: String) {
        val safeMime = if (mimeType.isBlank() || mimeType == "application/octet-stream") {
            "application/octet-stream"
        } else {
            mimeType
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val resolver = context.contentResolver
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, fileName)
                put(MediaStore.Downloads.MIME_TYPE, safeMime)
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("Unable to create MediaStore entry")

            try {
                resolver.openOutputStream(uri)?.use { out ->
                    FileInputStream(sourceFile).use { input ->
                        copyWith16KbBuffer(input, out, null)
                    }
                } ?: throw IllegalStateException("Unable to open MediaStore output stream")

                values.clear()
                values.put(MediaStore.Downloads.IS_PENDING, 0)
                resolver.update(uri, values, null, null)
            } catch (e: Exception) {
                resolver.delete(uri, null, null)
                throw e
            }
        } else {
            @Suppress("DEPRECATION")
            val downloadsDir =
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            if (!downloadsDir.exists()) downloadsDir.mkdirs()
            val targetFile = uniqueFile(downloadsDir, fileName)
            FileInputStream(sourceFile).use { input ->
                FileOutputStream(targetFile).use { out ->
                    copyWith16KbBuffer(input, out, null)
                }
            }
        }
    }

    private fun uniqueFile(dir: File, fileName: String): File {
        var candidate = File(dir, fileName)
        if (!candidate.exists()) return candidate
        val dotIndex = fileName.lastIndexOf('.')
        val base = if (dotIndex > 0) fileName.substring(0, dotIndex) else fileName
        val ext = if (dotIndex > 0) fileName.substring(dotIndex) else ""
        var counter = 1
        while (candidate.exists()) {
            candidate = File(dir, "${base}_($counter)$ext")
            counter++
        }
        return candidate
    }

    private fun openConnection(urlString: String, userAgent: String, method: String): HttpURLConnection {
        val conn = URL(urlString).openConnection() as HttpURLConnection
        conn.requestMethod = method
        conn.connectTimeout = 15000
        conn.readTimeout = 20000
        conn.instanceFollowRedirects = true
        conn.setRequestProperty("User-Agent", userAgent)
        val cookies = CookieManager.getInstance().getCookie(urlString)
        if (!cookies.isNullOrBlank()) {
            conn.setRequestProperty("Cookie", cookies)
        }
        return conn
    }

    companion object {
        private const val THREAD_COUNT = 4
        private const val BUFFER_SIZE_16KB = 16 * 1024
        private const val MIN_MULTITHREAD_SIZE = 256 * 1024L
        private const val MAX_REDIRECTS = 10
    }
}
