package com.shivaji.browser

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.os.Build
import android.os.Bundle
import android.util.Patterns
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.JavascriptInterface
import android.webkit.URLUtil
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.updateLayoutParams
import androidx.dynamicanimation.animation.DynamicAnimation
import androidx.dynamicanimation.animation.SpringAnimation
import androidx.dynamicanimation.animation.SpringForce
import androidx.lifecycle.lifecycleScope
import com.shivaji.browser.databinding.ActivityMainBinding
import java.net.URLEncoder
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var adBlocker: AdBlocker
    private lateinit var downloader: ParallelDownloader

    private var isBottomBarHidden = false
    private var accumulatedScrollDelta = 0
    private var defaultBottomMarginPx = 0

    private var pendingDownload: PendingDownload? = null

    private data class PendingDownload(
        val url: String,
        val fileName: String,
        val mimeType: String,
        val userAgent: String
    )

    private val storagePermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) {
                pendingDownload?.let {
                    pendingDownload = null
                    executeDownload(it)
                }
            } else {
                pendingDownload = null
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Edge-to-Edge Fullscreen Display
        WindowCompat.setDecorFitsSystemWindows(window, false)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        defaultBottomMarginPx = resources.displayMetrics.density.let { (12f * it).toInt() }
        adBlocker = AdBlocker(this)
        downloader = ParallelDownloader(this)

        setupWindowInsets()
        setupWebView()
        setupControls()
        setupBackNavigation()
        runSpringLaunchAnimation()

        val initialUrl = intent?.dataString
        if (!initialUrl.isNullOrBlank()) {
            loadInput(initialUrl)
        } else {
            loadStartPage()
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        intent.dataString?.let { url ->
            if (url.isNotBlank()) loadInput(url)
        }
    }

    private fun setupWindowInsets() {
        ViewCompat.setOnApplyWindowInsetsListener(binding.rootContainer) { _, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            val imeInsets = insets.getInsets(WindowInsetsCompat.Type.ime())

            // Keep WebView edge-to-edge while padding top progress bar below status bar
            binding.pageProgressBar.updateLayoutParams<androidx.constraintlayout.widget.ConstraintLayout.LayoutParams> {
                topMargin = systemBars.top
            }

            // Smoothly lift bottom pill bar above soft keyboard (IME) or navigation bar
            val bottomOffset = maxOf(systemBars.bottom, imeInsets.bottom) + defaultBottomMarginPx
            binding.bottomBarContainer.updateLayoutParams<androidx.constraintlayout.widget.ConstraintLayout.LayoutParams> {
                bottomMargin = bottomOffset
            }

            if (imeInsets.bottom > systemBars.bottom && isBottomBarHidden) {
                showBottomBarSpring()
            }

            insets
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        binding.webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            loadWithOverviewMode = true
            useWideViewPort = true
            builtInZoomControls = true
            displayZoomControls = false
            setSupportMultipleWindows(false)
            javaScriptCanOpenWindowsAutomatically = false
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            cacheMode = WebSettings.LOAD_DEFAULT
        }

        binding.webView.addJavascriptInterface(SafariBridge(), "SafariBridge")

        binding.webView.webViewClient = object : WebViewClient() {

            override fun shouldInterceptRequest(
                view: WebView?,
                request: WebResourceRequest?
            ): WebResourceResponse? {
                val url = request?.url?.toString()
                if (adBlocker.isAdOrTracker(url)) {
                    return adBlocker.emptyResponse()
                }
                return super.shouldInterceptRequest(view, request)
            }

            override fun shouldOverrideUrlLoading(
                view: WebView?,
                request: WebResourceRequest?
            ): Boolean {
                val url = request?.url?.toString() ?: return false
                if (adBlocker.isAdOrTracker(url)) {
                    return true
                }
                return false
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                super.onPageStarted(view, url, favicon)
                updateAddressBar(url)
                updateNavButtons()
                showBottomBarSpring()
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                updateAddressBar(url)
                updateNavButtons()
                binding.pageProgressBar.visibility = View.GONE

                if (url == START_PAGE_URL) {
                    val count = adBlocker.getTotalBlockedCount()
                    binding.webView.evaluateJavascript(
                        "if(window.updatePrivacyCount){window.updatePrivacyCount($count);}",
                        null
                    )
                }
            }
        }

        binding.webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                if (newProgress in 1..99) {
                    binding.pageProgressBar.visibility = View.VISIBLE
                    binding.pageProgressBar.progress = newProgress
                } else {
                    binding.pageProgressBar.visibility = View.GONE
                }
            }
        }

        binding.webView.setDownloadListener { url, userAgent, contentDisposition, mimetype, _ ->
            val fileName = URLUtil.guessFileName(url, contentDisposition, mimetype)
            val request = PendingDownload(
                url = url,
                fileName = fileName,
                mimeType = mimetype ?: "application/octet-stream",
                userAgent = userAgent ?: binding.webView.settings.userAgentString
            )
            beginDownloadWithPermissionCheck(request)
        }

        // Auto-hide/show bottom pill bar on scroll with iOS spring feel
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            binding.webView.setOnScrollChangeListener { _, _, scrollY, _, oldScrollY ->
                val dy = scrollY - oldScrollY
                if (binding.etUrlBar.hasFocus()) return@setOnScrollChangeListener

                accumulatedScrollDelta += dy
                if (scrollY <= 16) {
                    accumulatedScrollDelta = 0
                    showBottomBarSpring()
                    return@setOnScrollChangeListener
                }

                if (accumulatedScrollDelta > 64 && !isBottomBarHidden) {
                    accumulatedScrollDelta = 0
                    hideBottomBarSpring()
                } else if (accumulatedScrollDelta < -48 && isBottomBarHidden) {
                    accumulatedScrollDelta = 0
                    showBottomBarSpring()
                }
            }
        }
    }

    private fun setupControls() {
        binding.btnBack.setOnClickListener {
            if (binding.webView.canGoBack()) {
                binding.webView.goBack()
            }
        }

        binding.btnForward.setOnClickListener {
            if (binding.webView.canGoForward()) {
                binding.webView.goForward()
            }
        }

        binding.btnRefresh.setOnClickListener {
            binding.webView.reload()
        }

        binding.btnHome.setOnClickListener {
            loadStartPage()
        }

        binding.btnCancelDownload.setOnClickListener {
            downloader.cancel()
            hideDownloadSheet()
        }

        binding.etUrlBar.setOnEditorActionListener { _, actionId, event ->
            val isEnter = event?.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN
            if (actionId == EditorInfo.IME_ACTION_GO || actionId == EditorInfo.IME_ACTION_SEARCH || isEnter) {
                val query = binding.etUrlBar.text?.toString()?.trim().orEmpty()
                if (query.isNotEmpty()) {
                    loadInput(query)
                }
                clearUrlFocus()
                true
            } else {
                false
            }
        }
    }

    private fun setupBackNavigation() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (binding.webView.canGoBack()) {
                    binding.webView.goBack()
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })
    }

    private fun runSpringLaunchAnimation() {
        val root = binding.rootContainer
        root.scaleX = 0.94f
        root.scaleY = 0.94f
        root.alpha = 0f

        root.animate()
            .alpha(1f)
            .setDuration(260L)
            .start()

        SpringAnimation(root, DynamicAnimation.SCALE_X, 1f).apply {
            spring = SpringForce(1f).apply {
                dampingRatio = SpringForce.DAMPING_RATIO_LOW_BOUNCY
                stiffness = SpringForce.STIFFNESS_LOW
            }
            start()
        }

        SpringAnimation(root, DynamicAnimation.SCALE_Y, 1f).apply {
            spring = SpringForce(1f).apply {
                dampingRatio = SpringForce.DAMPING_RATIO_LOW_BOUNCY
                stiffness = SpringForce.STIFFNESS_LOW
            }
            start()
        }
    }

    private fun hideBottomBarSpring() {
        isBottomBarHidden = true
        val targetY = (binding.bottomBarContainer.height + defaultBottomMarginPx * 3).toFloat()
        SpringAnimation(binding.bottomBarContainer, DynamicAnimation.TRANSLATION_Y, targetY).apply {
            spring = SpringForce(targetY).apply {
                dampingRatio = SpringForce.DAMPING_RATIO_NO_BOUNCY
                stiffness = SpringForce.STIFFNESS_MEDIUM
            }
            start()
        }
        binding.bottomBarContainer.animate().alpha(0f).setDuration(180L).start()
    }

    private fun showBottomBarSpring() {
        isBottomBarHidden = false
        SpringAnimation(binding.bottomBarContainer, DynamicAnimation.TRANSLATION_Y, 0f).apply {
            spring = SpringForce(0f).apply {
                dampingRatio = SpringForce.DAMPING_RATIO_LOW_BOUNCY
                stiffness = SpringForce.STIFFNESS_LOW
            }
            start()
        }
        binding.bottomBarContainer.animate().alpha(1f).setDuration(180L).start()
    }

    private fun loadStartPage() {
        binding.webView.loadUrl(START_PAGE_URL)
        updateAddressBar(START_PAGE_URL)
    }

    private fun loadInput(raw: String) {
        val trimmed = raw.trim()
        val url = when {
            trimmed.startsWith("http://", ignoreCase = true) ||
                trimmed.startsWith("https://", ignoreCase = true) -> trimmed
            Patterns.WEB_URL.matcher(trimmed).matches() && !trimmed.contains(" ") -> "https://$trimmed"
            else -> "https://www.google.com/search?q=" + URLEncoder.encode(trimmed, "UTF-8")
        }
        binding.webView.loadUrl(url)
    }

    private fun updateAddressBar(url: String?) {
        if (binding.etUrlBar.hasFocus()) return
        if (url.isNullOrBlank() || url == "about:blank" || url == START_PAGE_URL) {
            binding.etUrlBar.setText("")
            binding.ivLockIcon.visibility = View.GONE
        } else {
            binding.etUrlBar.setText(url)
            binding.ivLockIcon.visibility =
                if (url.startsWith("https://", ignoreCase = true)) View.VISIBLE else View.GONE
        }
    }

    private fun updateNavButtons() {
        val canBack = binding.webView.canGoBack()
        val canForward = binding.webView.canGoForward()
        binding.btnBack.isEnabled = canBack
        binding.btnBack.alpha = if (canBack) 1.0f else 0.35f
        binding.btnForward.isEnabled = canForward
        binding.btnForward.alpha = if (canForward) 1.0f else 0.35f
    }

    private fun clearUrlFocus() {
        binding.etUrlBar.clearFocus()
        val imm = getSystemService(INPUT_METHOD_SERVICE) as? InputMethodManager
        imm?.hideSoftInputFromWindow(binding.etUrlBar.windowToken, 0)
    }

    private fun beginDownloadWithPermissionCheck(request: PendingDownload) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            val granted = ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) {
                pendingDownload = request
                storagePermissionLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                return
            }
        }
        executeDownload(request)
    }

    private fun executeDownload(request: PendingDownload) {
        downloader.startDownload(
            rawUrl = request.url,
            fileName = request.fileName,
            mimeType = request.mimeType,
            userAgent = request.userAgent,
            scope = lifecycleScope,
            listener = object : ParallelDownloader.Listener {
                override fun onStart(fileName: String, totalBytes: Long) {
                    showDownloadSheet()
                    binding.tvDownloadFileName.text = fileName
                    binding.downloadProgressBar.isIndeterminate = totalBytes <= 0
                    binding.downloadProgressBar.progress = 0
                    binding.tvDownloadSpeed.text = "0 KB/s"
                    binding.tvDownloadSize.text = if (totalBytes > 0) {
                        "0 B / ${formatBytes(totalBytes)}"
                    } else {
                        "Preparing..."
                    }
                    binding.tvDownloadEta.text = "ETA --"
                }

                override fun onProgress(
                    downloadedBytes: Long,
                    totalBytes: Long,
                    speedBytesPerSec: Long,
                    etaSeconds: Long
                ) {
                    if (totalBytes > 0) {
                        binding.downloadProgressBar.isIndeterminate = false
                        val pct = ((downloadedBytes * 100L) / totalBytes).toInt().coerceIn(0, 100)
                        binding.downloadProgressBar.progress = pct
                        binding.tvDownloadSize.text =
                            "${formatBytes(downloadedBytes)} / ${formatBytes(totalBytes)}"
                    } else {
                        binding.downloadProgressBar.isIndeterminate = true
                        binding.tvDownloadSize.text = formatBytes(downloadedBytes)
                    }
                    binding.tvDownloadSpeed.text = "${formatBytes(speedBytesPerSec)}/s"
                    binding.tvDownloadEta.text = formatEta(etaSeconds)
                }

                override fun onComplete(fileName: String) {
                    binding.downloadProgressBar.isIndeterminate = false
                    binding.downloadProgressBar.progress = 100
                    binding.tvDownloadSpeed.text = "Saved"
                    binding.tvDownloadEta.text = "Done"
                    binding.downloadSheetContainer.postDelayed({ hideDownloadSheet() }, 2200L)
                }

                override fun onError(message: String) {
                    binding.tvDownloadSpeed.text = "Failed"
                    binding.tvDownloadEta.text = ""
                    binding.downloadSheetContainer.postDelayed({ hideDownloadSheet() }, 2500L)
                }

                override fun onCancelled() {
                    hideDownloadSheet()
                }
            }
        )
    }

    private fun showDownloadSheet() {
        showBottomBarSpring()
        val sheet = binding.downloadSheetContainer
        if (sheet.visibility == View.VISIBLE) return
        sheet.alpha = 0f
        sheet.translationY = 40f
        sheet.visibility = View.VISIBLE
        sheet.animate().alpha(1f).setDuration(180L).start()
        SpringAnimation(sheet, DynamicAnimation.TRANSLATION_Y, 0f).apply {
            spring = SpringForce(0f).apply {
                dampingRatio = SpringForce.DAMPING_RATIO_LOW_BOUNCY
                stiffness = SpringForce.STIFFNESS_LOW
            }
            start()
        }
    }

    private fun hideDownloadSheet() {
        val sheet = binding.downloadSheetContainer
        if (sheet.visibility != View.VISIBLE) return
        sheet.animate()
            .alpha(0f)
            .translationY(36f)
            .setDuration(180L)
            .withEndAction { sheet.visibility = View.GONE }
            .start()
    }

    private fun formatBytes(bytes: Long): String {
        if (bytes < 1024L) return "$bytes B"
        val kb = bytes / 1024.0
        if (kb < 1024.0) return String.format(Locale.US, "%.1f KB", kb)
        val mb = kb / 1024.0
        if (mb < 1024.0) return String.format(Locale.US, "%.1f MB", mb)
        val gb = mb / 1024.0
        return String.format(Locale.US, "%.2f GB", gb)
    }

    private fun formatEta(seconds: Long): String {
        if (seconds < 0) return "ETA --"
        if (seconds < 60) return "ETA ${seconds}s"
        val mins = seconds / 60
        val remSec = seconds % 60
        return "ETA ${mins}m ${remSec}s"
    }

    inner class SafariBridge {
        @JavascriptInterface
        fun getBlockedCount(): Int = adBlocker.getTotalBlockedCount()
    }

    companion object {
        private const val START_PAGE_URL = "file:///android_asset/start.html"
    }
}
