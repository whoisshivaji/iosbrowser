package com.shivaji.browser

import android.Manifest
import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Patterns
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.URLUtil
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.updateLayoutParams
import androidx.dynamicanimation.animation.DynamicAnimation
import androidx.dynamicanimation.animation.SpringAnimation
import androidx.dynamicanimation.animation.SpringForce
import androidx.lifecycle.lifecycleScope
import com.shivaji.browser.databinding.ActivityMainBinding
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var adBlocker: AdBlocker
    private lateinit var downloader: ParallelDownloader

    private var isBottomBarHidden = false
    private var accumulatedScrollDelta = 0
    private var defaultBottomMarginPx = 0

    private var pendingDownload: PendingDownload? = null
    private var isDesktopMode = false
    private var mobileUserAgent: String = ""

    private data class BrowserTab(
        val id: Long,
        var title: String,
        var url: String,
        val webView: WebView
    )

    private val tabs = mutableListOf<BrowserTab>()
    private var currentTabIndex = -1
    private var nextTabId = 1L

    private data class PendingDownload(
        val url: String,
        val fileName: String,
        val mimeType: String,
        val userAgent: String
    )

    private val storagePermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) {
                pendingDownload?.let {
                    pendingDownload = null
                    executeDownload(it)
                }
            } else {
                pendingDownload = null
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        WindowCompat.setDecorFitsSystemWindows(window, false)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        defaultBottomMarginPx = resources.displayMetrics.density.let { (12f * it).toInt() }
        adBlocker = AdBlocker(this)
        downloader = ParallelDownloader(this)

        setupWindowInsets()
        setupControls()
        setupBackNavigation()
        runSpringLaunchAnimation()

        val initialUrl = intent?.dataString
        if (!initialUrl.isNullOrBlank()) {
            openNewTab(normalizeUrl(initialUrl))
        } else {
            openNewTab(START_PAGE_URL)
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        intent.dataString?.let { url ->
            if (url.isNotBlank()) openNewTab(normalizeUrl(url))
        }
    }

    private fun currentTab(): BrowserTab? = tabs.getOrNull(currentTabIndex)

    private fun setupWindowInsets() {
        ViewCompat.setOnApplyWindowInsetsListener(binding.rootContainer) { _, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            val imeInsets = insets.getInsets(WindowInsetsCompat.Type.ime())

            binding.webViewContainer.updateLayoutParams<androidx.constraintlayout.widget.ConstraintLayout.LayoutParams> {
                topMargin = systemBars.top
            }
            binding.pageProgressBar.updateLayoutParams<androidx.constraintlayout.widget.ConstraintLayout.LayoutParams> {
                topMargin = systemBars.top
            }

            val bottomOffset = maxOf(systemBars.bottom, imeInsets.bottom) + defaultBottomMarginPx
            binding.bottomBarContainer.updateLayoutParams<androidx.constraintlayout.widget.ConstraintLayout.LayoutParams> {
                bottomMargin = bottomOffset
            }

            if (imeInsets.bottom > systemBars.bottom && isBottomBarHidden) {
                showBottomBarSpring()
            }

            insets
        }
    }

    private fun openNewTab(url: String) {
        val tabId = nextTabId++
        val wv = createWebView(tabId)
        val tab = BrowserTab(
            id = tabId,
            title = if (url == START_PAGE_URL) "Start Page" else url,
            url = url,
            webView = wv
        )
        tabs.add(tab)
        binding.webViewContainer.addView(
            wv,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )
        switchToTab(tabs.size - 1)
        wv.loadUrl(url)
    }

    private fun switchToTab(index: Int) {
        if (index !in tabs.indices) return
        currentTabIndex = index
        tabs.forEachIndexed { idx, t ->
            t.webView.visibility = if (idx == index) View.VISIBLE else View.GONE
        }
        val active = tabs[index]
        updateAddressBar(active.url)
        updateNavButtons()
        updateTabBadge()
        binding.pageProgressBar.visibility = View.GONE
    }

    private fun closeTab(index: Int) {
        if (index !in tabs.indices) return
        val removed = tabs.removeAt(index)
        binding.webViewContainer.removeView(removed.webView)
        removed.webView.destroy()

        if (tabs.isEmpty()) {
            currentTabIndex = -1
            openNewTab(START_PAGE_URL)
        } else {
            val newIndex = if (currentTabIndex >= tabs.size) tabs.size - 1
            else if (index < currentTabIndex) currentTabIndex - 1
            else currentTabIndex
            switchToTab(newIndex)
        }
        if (binding.tabsSheetContainer.visibility == View.VISIBLE) {
            renderTabsList()
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun createWebView(tabId: Long): WebView {
        val wv = WebView(this)
        if (mobileUserAgent.isEmpty()) {
            mobileUserAgent = wv.settings.userAgentString
        }
        wv.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            loadWithOverviewMode = true
            useWideViewPort = true
            builtInZoomControls = true
            displayZoomControls = false
            setSupportMultipleWindows(false)
            javaScriptCanOpenWindowsAutomatically = false
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            cacheMode = WebSettings.LOAD_DEFAULT
            userAgentString = if (isDesktopMode) DESKTOP_USER_AGENT else mobileUserAgent
        }

        wv.addJavascriptInterface(SafariBridge(), "SafariBridge")

        wv.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView?,
                request: WebResourceRequest?
            ): WebResourceResponse? {
                val url = request?.url?.toString()
                if (adBlocker.isAdOrTracker(url)) {
                    return adBlocker.emptyResponse()
                }
                return super.shouldInterceptRequest(view, request)
            }

            override fun shouldOverrideUrlLoading(
                view: WebView?,
                request: WebResourceRequest?
            ): Boolean {
                val url = request?.url?.toString() ?: return false
                return adBlocker.isAdOrTracker(url)
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                super.onPageStarted(view, url, favicon)
                val tab = tabs.firstOrNull { it.id == tabId }
                if (tab != null && !url.isNullOrBlank()) {
                    tab.url = url
                    if (url == START_PAGE_URL) tab.title = "Start Page"
                }
                if (currentTab()?.id == tabId) {
                    updateAddressBar(url)
                    updateNavButtons()
                    showBottomBarSpring()
                }
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                val tab = tabs.firstOrNull { it.id == tabId }
                if (tab != null) {
                    if (!url.isNullOrBlank()) tab.url = url
                    val pageTitle = view?.title
                    if (!pageTitle.isNullOrBlank() && url != START_PAGE_URL) {
                        tab.title = pageTitle
                    } else if (url == START_PAGE_URL) {
                        tab.title = "Start Page"
                    }
                }
                if (currentTab()?.id == tabId) {
                    updateAddressBar(url)
                    updateNavButtons()
                    binding.pageProgressBar.visibility = View.GONE
                }
                if (url == START_PAGE_URL) {
                    val count = adBlocker.getTotalBlockedCount()
                    view?.evaluateJavascript(
                        "if(window.updatePrivacyCount){window.updatePrivacyCount($count);}",
                        null
                    )
                }
            }
        }

        wv.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                if (currentTab()?.id != tabId) return
                if (newProgress in 1..99) {
                    binding.pageProgressBar.visibility = View.VISIBLE
                    binding.pageProgressBar.progress = newProgress
                } else {
                    binding.pageProgressBar.visibility = View.GONE
                }
            }

            override fun onReceivedTitle(view: WebView?, title: String?) {
                val tab = tabs.firstOrNull { it.id == tabId } ?: return
                if (!title.isNullOrBlank() && tab.url != START_PAGE_URL) {
                    tab.title = title
                }
            }
        }

        wv.setDownloadListener { url, userAgent, contentDisposition, mimetype, _ ->
            val fileName = URLUtil.guessFileName(url, contentDisposition, mimetype)
            val request = PendingDownload(
                url = url,
                fileName = fileName,
                mimeType = mimetype ?: "application/octet-stream",
                userAgent = userAgent ?: wv.settings.userAgentString
            )
            beginDownloadWithPermissionCheck(request)
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            wv.setOnScrollChangeListener { _, _, scrollY, _, oldScrollY ->
                if (currentTab()?.id != tabId) return@setOnScrollChangeListener
                val dy = scrollY - oldScrollY
                if (binding.etUrlBar.hasFocus()) return@setOnScrollChangeListener

                accumulatedScrollDelta += dy
                if (scrollY <= 16) {
                    accumulatedScrollDelta = 0
                    showBottomBarSpring()
                    return@setOnScrollChangeListener
                }

                if (accumulatedScrollDelta > 64 && !isBottomBarHidden) {
                    accumulatedScrollDelta = 0
                    hideBottomBarSpring()
                } else if (accumulatedScrollDelta < -48 && isBottomBarHidden) {
                    accumulatedScrollDelta = 0
                    showBottomBarSpring()
                }
            }
        }

        return wv
    }

    private fun setupControls() {
        binding.btnBack.setOnClickListener {
            val wv = currentTab()?.webView ?: return@setOnClickListener
            if (wv.canGoBack()) wv.goBack()
        }

        binding.btnForward.setOnClickListener {
            val wv = currentTab()?.webView ?: return@setOnClickListener
            if (wv.canGoForward()) wv.goForward()
        }

        binding.btnRefresh.setOnClickListener {
            currentTab()?.webView?.reload()
        }

        binding.btnTabs.setOnClickListener {
            toggleTabsSheet()
        }

        binding.btnNewTab.setOnClickListener {
            hideAllSheets()
            openNewTab(START_PAGE_URL)
        }

        binding.btnCloseTabsSheet.setOnClickListener {
            hideAllSheets()
        }

        binding.btnMore.setOnClickListener {
            toggleMenuSheet()
        }

        binding.btnCloseMenu.setOnClickListener {
            hideAllSheets()
        }

        binding.btnCloseDownloadsList.setOnClickListener {
            hideAllSheets()
        }

        binding.menuDownloads.setOnClickListener {
            binding.menuSheetContainer.visibility = View.GONE
            showDownloadsListSheet()
        }

        binding.btnOpenSystemDownloads.setOnClickListener {
            try {
                startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS))
            } catch (_: Exception) {
                Toast.makeText(this, "Open your Files app > Downloads", Toast.LENGTH_SHORT).show()
            }
        }

        binding.menuDesktopSite.setOnClickListener {
            isDesktopMode = !isDesktopMode
            val ua = if (isDesktopMode) DESKTOP_USER_AGENT else mobileUserAgent
            tabs.forEach { it.webView.settings.userAgentString = ua }
            binding.tvDesktopStatus.text = if (isDesktopMode) "ON" else "OFF"
            binding.tvDesktopStatus.setTextColor(
                if (isDesktopMode) Color.parseColor("#FF0A84FF") else Color.parseColor("#99EBEBF5")
            )
            hideAllSheets()
            currentTab()?.webView?.reload()
        }

        binding.menuShare.setOnClickListener {
            hideAllSheets()
            val currentUrl = currentTab()?.webView?.url
            if (!currentUrl.isNullOrBlank() && currentUrl != START_PAGE_URL) {
                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, currentUrl)
                }
                startActivity(Intent.createChooser(shareIntent, "Share link"))
            }
        }

        binding.menuClearData.setOnClickListener {
            hideAllSheets()
            tabs.forEach {
                it.webView.clearHistory()
                it.webView.clearCache(true)
            }
            CookieManager.getInstance().removeAllCookies(null)
            CookieManager.getInstance().flush()
            Toast.makeText(this, "History & cache cleared", Toast.LENGTH_SHORT).show()
        }

        binding.btnCancelDownload.setOnClickListener {
            downloader.cancel()
            hideDownloadSheet()
        }

        binding.etUrlBar.setOnEditorActionListener { _, actionId, event ->
            val isEnter = event?.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN
            if (actionId == EditorInfo.IME_ACTION_GO || actionId == EditorInfo.IME_ACTION_SEARCH || isEnter) {
                val query = binding.etUrlBar.text?.toString()?.trim().orEmpty()
                if (query.isNotEmpty()) {
                    currentTab()?.webView?.loadUrl(normalizeUrl(query))
                }
                clearUrlFocus()
                true
            } else {
                false
            }
        }
    }

    private fun setupBackNavigation() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (binding.tabsSheetContainer.visibility == View.VISIBLE ||
                    binding.menuSheetContainer.visibility == View.VISIBLE ||
                    binding.downloadsListContainer.visibility == View.VISIBLE
                ) {
                    hideAllSheets()
                    return
                }
                val wv = currentTab()?.webView
                if (wv != null && wv.canGoBack()) {
                    wv.goBack()
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })
    }

    private fun runSpringLaunchAnimation() {
        val root = binding.rootContainer
        root.scaleX = 0.94f
        root.scaleY = 0.94f
        root.alpha = 0f

        root.animate().alpha(1f).setDuration(260L).start()

        SpringAnimation(root, DynamicAnimation.SCALE_X, 1f).apply {
            spring = SpringForce(1f).apply {
                dampingRatio = SpringForce.DAMPING_RATIO_LOW_BOUNCY
                stiffness = SpringForce.STIFFNESS_LOW
            }
            start()
        }

        SpringAnimation(root, DynamicAnimation.SCALE_Y, 1f).apply {
            spring = SpringForce(1f).apply {
                dampingRatio = SpringForce.DAMPING_RATIO_LOW_BOUNCY
                stiffness = SpringForce.STIFFNESS_LOW
            }
            start()
        }
    }

    private fun hideBottomBarSpring() {
        isBottomBarHidden = true
        val targetY = (binding.bottomBarContainer.height + defaultBottomMarginPx * 3).toFloat()
        SpringAnimation(binding.bottomBarContainer, DynamicAnimation.TRANSLATION_Y, targetY).apply {
            spring = SpringForce(targetY).apply {
                dampingRatio = SpringForce.DAMPING_RATIO_NO_BOUNCY
                stiffness = SpringForce.STIFFNESS_MEDIUM
            }
            start()
        }
        binding.bottomBarContainer.animate().alpha(0f).setDuration(180L).start()
    }

    private fun showBottomBarSpring() {
        isBottomBarHidden = false
        SpringAnimation(binding.bottomBarContainer, DynamicAnimation.TRANSLATION_Y, 0f).apply {
            spring = SpringForce(0f).apply {
                dampingRatio = SpringForce.DAMPING_RATIO_LOW_BOUNCY
                stiffness = SpringForce.STIFFNESS_LOW
            }
            start()
        }
        binding.bottomBarContainer.animate().alpha(1f).setDuration(180L).start()
    }

    private fun normalizeUrl(raw: String): String {
        val trimmed = raw.trim()
        return when {
            trimmed.startsWith("http://", ignoreCase = true) ||
                trimmed.startsWith("https://", ignoreCase = true) -> trimmed
            Patterns.WEB_URL.matcher(trimmed).matches() && !trimmed.contains(" ") -> "https://$trimmed"
            else -> "https://www.google.com/search?q=" + URLEncoder.encode(trimmed, "UTF-8")
        }
    }

    private fun updateAddressBar(url: String?) {
        if (binding.etUrlBar.hasFocus()) return
        if (url.isNullOrBlank() || url == "about:blank" || url == START_PAGE_URL) {
            binding.etUrlBar.setText("")
            binding.ivLockIcon.visibility = View.GONE
        } else {
            binding.etUrlBar.setText(url)
            binding.ivLockIcon.visibility =
                if (url.startsWith("https://", ignoreCase = true)) View.VISIBLE else View.GONE
        }
    }

    private fun updateNavButtons() {
        val wv = currentTab()?.webView
        val canBack = wv?.canGoBack() == true
        val canForward = wv?.canGoForward() == true
        binding.btnBack.isEnabled = canBack
        binding.btnBack.alpha = if (canBack) 1.0f else 0.35f
        binding.btnForward.isEnabled = canForward
        binding.btnForward.alpha = if (canForward) 1.0f else 0.35f
    }

    private fun updateTabBadge() {
        binding.tvTabCountBadge.text = tabs.size.toString()
    }

    private fun clearUrlFocus() {
        binding.etUrlBar.clearFocus()
        val imm = getSystemService(INPUT_METHOD_SERVICE) as? InputMethodManager
        imm?.hideSoftInputFromWindow(binding.etUrlBar.windowToken, 0)
    }

    private fun toggleTabsSheet() {
        if (binding.tabsSheetContainer.visibility == View.VISIBLE) {
            hideAllSheets()
        } else {
            binding.menuSheetContainer.visibility = View.GONE
            binding.downloadsListContainer.visibility = View.GONE
            renderTabsList()
            animateSheetIn(binding.tabsSheetContainer)
        }
    }

    private fun renderTabsList() {
        binding.tvTabsHeader.text = "Tabs (${tabs.size})"
        binding.tabsItemsLayout.removeAllViews()
        tabs.forEachIndexed { index, tab ->
            val isActive = index == currentTabIndex
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(16, 18, 12, 18)
                setBackgroundResource(
                    if (isActive) R.drawable.glass_url_inner_bg else android.R.color.transparent
                )
                isClickable = true
                isFocusable = true
                setOnClickListener {
                    switchToTab(index)
                    hideAllSheets()
                }
            }
            val textCol = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            val tvTitle = TextView(this).apply {
                text = tab.title
                setTextColor(if (isActive) Color.parseColor("#FF0A84FF") else Color.WHITE)
                textSize = 14f
                maxLines = 1
            }
            val tvUrl = TextView(this).apply {
                text = if (tab.url == START_PAGE_URL) "Start Page" else tab.url
                setTextColor(Color.parseColor("#99EBEBF5"))
                textSize = 11.5f
                maxLines = 1
            }
            textCol.addView(tvTitle)
            textCol.addView(tvUrl)

            val closeBtn = ImageButton(this).apply {
                setImageResource(R.drawable.ic_ios_close)
                setBackgroundColor(Color.TRANSPARENT)
                setPadding(12, 12, 12, 12)
                setOnClickListener { closeTab(index) }
            }

            row.addView(textCol)
            row.addView(closeBtn)
            binding.tabsItemsLayout.addView(row)
        }
    }

    private fun toggleMenuSheet() {
        if (binding.menuSheetContainer.visibility == View.VISIBLE) {
            hideAllSheets()
        } else {
            binding.tabsSheetContainer.visibility = View.GONE
            binding.downloadsListContainer.visibility = View.GONE
            binding.tvDownloadsCount.text = getDownloadRecords().length().toString()
            animateSheetIn(binding.menuSheetContainer)
        }
    }

    private fun showDownloadsListSheet() {
        val records = getDownloadRecords()
        binding.downloadsItemsLayout.removeAllViews()
        if (records.length() == 0) {
            binding.tvNoDownloads.visibility = View.VISIBLE
        } else {
            binding.tvNoDownloads.visibility = View.GONE
            for (i in records.length() - 1 downTo 0) {
                val obj = records.getJSONObject(i)
                val name = obj.optString("name", "File")
                val size = obj.optLong("size", 0L)
                val uriStr = obj.optString("uri", "")
                val mime = obj.optString("mime", "application/octet-stream")

                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    setPadding(8, 18, 8, 18)
                    isClickable = true
                    isFocusable = true
                    setOnClickListener {
                        if (uriStr.isNotBlank()) {
                            try {
                                val openIntent = Intent(Intent.ACTION_VIEW).apply {
                                    setDataAndType(Uri.parse(uriStr), mime)
                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                }
                                startActivity(openIntent)
                            } catch (_: Exception) {
                                try {
                                    startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS))
                                } catch (_: Exception) {
                                    Toast.makeText(this@MainActivity, "Saved in Downloads folder", Toast.LENGTH_SHORT).show()
                                }
                            }
                        }
                    }
                }
                val tvName = TextView(this).apply {
                    text = name
                    setTextColor(Color.WHITE)
                    textSize = 13.5f
                    maxLines = 1
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                }
                val tvSize = TextView(this).apply {
                    text = formatBytes(size)
                    setTextColor(Color.parseColor("#99EBEBF5"))
                    textSize = 12f
                }
                row.addView(tvName)
                row.addView(tvSize)
                binding.downloadsItemsLayout.addView(row)
            }
        }
        animateSheetIn(binding.downloadsListContainer)
    }

    private fun animateSheetIn(sheet: View) {
        sheet.alpha = 0f
        sheet.translationY = 36f
        sheet.visibility = View.VISIBLE
        sheet.animate().alpha(1f).setDuration(180L).start()
        SpringAnimation(sheet, DynamicAnimation.TRANSLATION_Y, 0f).apply {
            spring = SpringForce(0f).apply {
                dampingRatio = SpringForce.DAMPING_RATIO_LOW_BOUNCY
                stiffness = SpringForce.STIFFNESS_LOW
            }
            start()
        }
    }

    private fun hideAllSheets() {
        binding.tabsSheetContainer.visibility = View.GONE
        binding.menuSheetContainer.visibility = View.GONE
        binding.downloadsListContainer.visibility = View.GONE
    }

    private fun saveDownloadRecord(name: String, size: Long, uri: String?, mime: String) {
        val prefs = getSharedPreferences("safari_downloads", MODE_PRIVATE)
        val arr = getDownloadRecords()
        val obj = JSONObject().apply {
            put("name", name)
            put("size", size)
            put("uri", uri.orEmpty())
            put("mime", mime)
        }
        arr.put(obj)
        prefs.edit().putString("items", arr.toString()).apply()
    }

    private fun getDownloadRecords(): JSONArray {
        val prefs = getSharedPreferences("safari_downloads", MODE_PRIVATE)
        val raw = prefs.getString("items", "[]") ?: "[]"
        return try {
            JSONArray(raw)
        } catch (_: Exception) {
            JSONArray()
        }
    }

    private fun beginDownloadWithPermissionCheck(request: PendingDownload) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            val granted = ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) {
                pendingDownload = request
                storagePermissionLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                return
            }
        }
        executeDownload(request)
    }

    private fun executeDownload(request: PendingDownload) {
        downloader.startDownload(
            rawUrl = request.url,
            fileName = request.fileName,
            mimeType = request.mimeType,
            userAgent = request.userAgent,
            scope = lifecycleScope,
            listener = object : ParallelDownloader.Listener {
                override fun onStart(fileName: String, totalBytes: Long) {
                    showDownloadSheet()
                    binding.tvDownloadFileName.text = fileName
                    binding.downloadProgressBar.isIndeterminate = totalBytes <= 0
                    binding.downloadProgressBar.progress = 0
                    binding.tvDownloadSpeed.text = "0 KB/s"
                    binding.tvDownloadSize.text = if (totalBytes > 0) {
                        "0 B / ${formatBytes(totalBytes)}"
                    } else {
                        "Preparing..."
                    }
                    binding.tvDownloadEta.text = "ETA --"
                }

                override fun onProgress(
                    downloadedBytes: Long,
                    totalBytes: Long,
                    speedBytesPerSec: Long,
                    etaSeconds: Long
                ) {
                    if (totalBytes > 0) {
                        binding.downloadProgressBar.isIndeterminate = false
                        val pct = ((downloadedBytes * 100L) / totalBytes).toInt().coerceIn(0, 100)
                        binding.downloadProgressBar.progress = pct
                        binding.tvDownloadSize.text =
                            "${formatBytes(downloadedBytes)} / ${formatBytes(totalBytes)}"
                    } else {
                        binding.downloadProgressBar.isIndeterminate = true
                        binding.tvDownloadSize.text = formatBytes(downloadedBytes)
                    }
                    binding.tvDownloadSpeed.text = "${formatBytes(speedBytesPerSec)}/s"
                    binding.tvDownloadEta.text = formatEta(etaSeconds)
                }

                override fun onComplete(fileName: String, totalBytes: Long, fileUri: String?) {
                    saveDownloadRecord(fileName, totalBytes, fileUri, request.mimeType)
                    binding.downloadProgressBar.isIndeterminate = false
                    binding.downloadProgressBar.progress = 100
                    binding.tvDownloadSpeed.text = "Saved"
                    binding.tvDownloadEta.text = "Done"
                    binding.downloadSheetContainer.postDelayed({ hideDownloadSheet() }, 2200L)
                }

                override fun onError(message: String) {
                    binding.tvDownloadSpeed.text = "Failed"
                    binding.tvDownloadEta.text = ""
                    binding.downloadSheetContainer.postDelayed({ hideDownloadSheet() }, 2500L)
                }

                override fun onCancelled() {
                    hideDownloadSheet()
                }
            }
        )
    }

    private fun showDownloadSheet() {
        showBottomBarSpring()
        val sheet = binding.downloadSheetContainer
        if (sheet.visibility == View.VISIBLE) return
        sheet.alpha = 0f
        sheet.translationY = 40f
        sheet.visibility = View.VISIBLE
        sheet.animate().alpha(1f).setDuration(180L).start()
        SpringAnimation(sheet, DynamicAnimation.TRANSLATION_Y, 0f).apply {
            spring = SpringForce(0f).apply {
                dampingRatio = SpringForce.DAMPING_RATIO_LOW_BOUNCY
                stiffness = SpringForce.STIFFNESS_LOW
            }
            start()
        }
    }

    private fun hideDownloadSheet() {
        val sheet = binding.downloadSheetContainer
        if (sheet.visibility != View.VISIBLE) return
        sheet.animate()
            .alpha(0f)
            .translationY(36f)
            .setDuration(180L)
            .withEndAction { sheet.visibility = View.GONE }
            .start()
    }

    private fun formatBytes(bytes: Long): String {
        if (bytes < 1024L) return "$bytes B"
        val kb = bytes / 1024.0
        if (kb < 1024.0) return String.format(Locale.US, "%.1f KB", kb)
        val mb = kb / 1024.0
        if (mb < 1024.0) return String.format(Locale.US, "%.1f MB", mb)
        val gb = mb / 1024.0
        return String.format(Locale.US, "%.2f GB", gb)
    }

    private fun formatEta(seconds: Long): String {
        if (seconds < 0) return "ETA --"
        if (seconds < 60) return "ETA ${seconds}s"
        val mins = seconds / 60
        val remSec = seconds % 60
        return "ETA ${mins}m ${remSec}s"
    }

    inner class SafariBridge {
        @JavascriptInterface
        fun getBlockedCount(): Int = adBlocker.getTotalBlockedCount()
    }

    companion object {
        private const val START_PAGE_URL = "file:///android_asset/start.html"
        private const val DESKTOP_USER_AGENT =
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"
    }
}
