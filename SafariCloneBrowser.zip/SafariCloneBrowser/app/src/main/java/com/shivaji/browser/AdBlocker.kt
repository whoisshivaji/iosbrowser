package com.shivaji.browser

import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import android.webkit.WebResourceResponse
import java.io.ByteArrayInputStream
import java.util.concurrent.atomic.AtomicInteger

class AdBlocker(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private val sessionBlocked = AtomicInteger(0)

    fun getTotalBlockedCount(): Int {
        return prefs.getInt(KEY_BLOCKED_COUNT, 0)
    }

    fun isAdOrTracker(url: String?): Boolean {
        if (url.isNullOrBlank()) return false
        val uri = try {
            Uri.parse(url)
        } catch (_: Exception) {
            return false
        }
        val host = uri.host?.lowercase() ?: return false
        val path = uri.path?.lowercase().orEmpty()

        // Check domain and all parent domain suffixes
        var candidate = host
        while (candidate.contains('.')) {
            if (BLOCKED_DOMAINS.contains(candidate)) {
                incrementCount()
                return true
            }
            candidate = candidate.substringAfter('.')
        }

        // Check common popunder / ad script patterns
        if (BLOCKED_PATH_TOKENS.any { path.contains(it) } && !host.endsWith("shivajiamihit.in")) {
            incrementCount()
            return true
        }

        return false
    }

    fun emptyResponse(): WebResourceResponse {
        return WebResourceResponse(
            "text/plain",
            "utf-8",
            ByteArrayInputStream(ByteArray(0))
        )
    }

    private fun incrementCount() {
        sessionBlocked.incrementAndGet()
        val updated = prefs.getInt(KEY_BLOCKED_COUNT, 0) + 1
        prefs.edit().putInt(KEY_BLOCKED_COUNT, updated).apply()
    }

    companion object {
        private const val PREFS_NAME = "safari_privacy_prefs"
        private const val KEY_BLOCKED_COUNT = "blocked_tracker_count"

        private val BLOCKED_PATH_TOKENS = listOf(
            "/pagead/",
            "/popunder",
            "/pop_under",
            "adsense.js",
            "adsbygoogle.js",
            "prebid.js",
            "gpt.js",
            "fbevents.js"
        )

        private val BLOCKED_DOMAINS = hashSetOf(
            "doubleclick.net",
            "googlesyndication.com",
            "googleadservices.com",
            "adservice.google.com",
            "google-analytics.com",
            "googletagmanager.com",
            "googletagservices.com",
            "pagead2.googlesyndication.com",
            "tpc.googlesyndication.com",
            "connect.facebook.net",
            "pixel.facebook.com",
            "an.facebook.com",
            "ads.yahoo.com",
            "adnxs.com",
            "criteo.com",
            "criteo.net",
            "taboola.com",
            "outbrain.com",
            "pubmatic.com",
            "rubiconproject.com",
            "openx.net",
            "casalemedia.com",
            "amazon-adsystem.com",
            "moatads.com",
            "scorecardresearch.com",
            "quantserve.com",
            "zedo.com",
            "popads.net",
            "popcash.net",
            "propellerads.com",
            "adsterra.com",
            "exoclick.com",
            "juicyads.com",
            "trafficjunky.net",
            "clickadu.com",
            "hilltopads.net",
            "mgid.com",
            "revcontent.com",
            "hotjar.com",
            "mixpanel.com",
            "amplitude.com",
            "segment.io",
            "segment.com",
            "branch.io",
            "appsflyer.com",
            "adjust.com",
            "chartbeat.com",
            "newrelic.com",
            "nr-data.net",
            "omtrdc.net",
            "demdex.net",
            "krxd.net",
            "bluekai.com",
            "bidswitch.net",
            "smartadserver.com",
            "33across.com",
            "sharethrough.com",
            "teads.tv",
            "yieldmo.com",
            "media.net",
            "adroll.com",
            "yandexadexchange.net",
            "mc.yandex.ru"
        )
    }
}
